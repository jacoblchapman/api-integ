=== Anteam Shipping ===

Contributors: anteam
Tags: anteam, shipping, logistics
Requires at least: 6.1
Tested up to: 6.2 
Stable tag: 1.0  
Requires PHP: 8.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html


This plugin integrates with the Anteam app to automatically ship compatible orders with the click of a button.

== Description ==

This plugin will allow you to easily and efficiently view Anteam compatible orders and create pickup requests for them with just the click of a button. The plugin has two main settings which can be toggled in the plugin settings (WooCommerce > Settings > Shipping > Anteam Shipping).

The first setting will add Anteam delivery as a shipping option at checkout, this will allow them to choose Anteam delivery themselves. If this option is enabled , all orders you see on the order approval page will be ones where the customer has selected Anteam shipping.

The second setting gives you, the shop owner, full control over what does and doesn't ship with Anteam. If this mode is selected, all Anteam compatible orders will be displayed in the order.

From there, it is as simple as clicking the approve / deny button. If you approve the order a pickup request will be automatically created and can be viewed in the Anteam app. If you deny the order it will be removed from the table and can be processed however you like.

== Installation ==

1. After installing and activating the plugin, navigate to WooCommerce > Settings > Shipping > Anteam Shipping.

2. Provide your store's pickup address and the contact name along with the number of the person who will meet the Anteam driver.

3. Obtain your authorization token from Anteam support, and enter it in the respective field.

4. Don't forget to save any changes made to the settings.


== Changelog ==

= 1.0 =
* Initial release of stable Anteam plugin